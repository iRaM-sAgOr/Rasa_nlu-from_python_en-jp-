## greeting path1
* greet
- utter_greet
* fine_normal
- utter_how_help

## greeting path2
* greet
- utter_greet
* fine_ask
- utter_reply_help

## assisting
* ask_help
- utter_ofc

## apple path3
* express_issue
- utter_what_model
* model_name
- utter_when
* year_buy
- utter_damage
* damage_ans
- utter_damage_rep
* prob1
- utter_alt1
* not_working
- utter_alt2
* not_working
- utter_alt3
* not_working
- utter_ticket_raised
* that_all
- utter_thank

## apple path4
* express_issue
- utter_what_model
* model_name
- utter_when
* year_buy
- utter_damage
* damage_ans
- utter_damage_rep
* prob
- utter_alt
* noo
- utter_please_try
* working
- utter_welcome

## apple path5
* greet
- utter_greet
* express_task
- utter_ques
* yess
- utter_ticket_raised

## apple path4_1
* express_issue
- utter_what_model
* model_name
- utter_when
* year_buy
- utter_damage
* damage_ans
- utter_damage_rep
* prob
- utter_alt
* noo
- utter_please_try
* not_working
- utter_ticket_raised

## apple path6
* greet
- utter_greet
* express_issue
- utter_what_problem
* no_idea
- utter_usual

## apple path 7
* my_device
- utter_what_problem
* no_idea
- utter_chose_proj
* proj_select
- utter_anything_else
* no_idea
- utter_usual

## apple path7_1
* my_device1
- utter_what_device
* device_name
- utter_what_model
* model_name
- utter_when
* year_buy
- utter_damage
* damage_ans
- utter_damage_rep
* prob1
- utter_alt1
* not_working
- utter_alt2
* not_working
- utter_alt3
* not_working
- utter_ticket_raised
* that_all
- utter_thank

