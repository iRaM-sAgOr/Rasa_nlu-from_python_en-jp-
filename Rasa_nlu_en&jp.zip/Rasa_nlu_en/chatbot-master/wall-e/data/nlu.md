## intent:greet
- hey
- hello
- hi
- good morning
- good evening
- good afternoon
- hey there
- hi there
- hii
- Hi

## intent:fine_ask
- I am good, how are you doing?
- I'm fine, how are you?
- I'm good, how are you?
- I am good, how are you?
- Doing good, how are you?
- Awesome, how are you?
- im fine, how are you?
- im good, how are you?
- I am doing good. How about you?

## intent:fine_normal
- I am doing great
- I'm doing great
- I'm fine
- I'm good
- Doing good
- Awesome
- im fine
- im good

## intent:news
- Share some latest news around the [world](category)?
- Share some latest news in [sports](category)?
- What is going on in [technology](category)?
- Tell me some news about [fashion](category)
- Tell me some news about [business](category)
- What is going on in [business](category)
- Tell me some news about [arts](category)
- What is going on in [arts](category)
- What is going on in [arts](category)
- What is cooking in [food](category)
- [movies](category)
- [magazine](category)
- [opinion](category)
- [science](category)

## intent:thanks
- Thanks
- Thank you so much

## intent:bye
- No, I am good as of now. Bye
- Bye
- Bbye
