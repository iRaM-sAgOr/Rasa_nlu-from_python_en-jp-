## Conversational Chatbot using Rasa Framework. The chatbot which is named iBot helps in solving customer problem related to Apple devices. In case iBot is not able to solve the problem then It will create a ticket with their customer service and share the ticket number with customer for them to track it.

### We have used Rasa NLU and Core to train the bot. We have developed a backend service also to create the ticket.

### We have also integrated with Slack to deploy our bot.
